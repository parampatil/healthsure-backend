from django.contrib import admin

# Register your models here.
from .models import Doctor_data,Insurance_Provider_data,Insurance_plan_data,Patient_data,Appointmnet_data,Medical_history_data,Symptom_Specialities_data
# # # Register your models here.

admin.site.register(Doctor_data)
admin.site.register(Insurance_Provider_data)
admin.site.register(Insurance_plan_data)
admin.site.register(Patient_data)
admin.site.register(Appointmnet_data)
admin.site.register(Medical_history_data)
admin.site.register(Symptom_Specialities_data)