from django.apps import AppConfig


class LinLoutConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lin_lout'
